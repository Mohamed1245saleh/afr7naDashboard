<template>
<v-container>
    <countries-table title="الدول" icon="language"/>
</v-container>
</template>

<script>
import CountriesTable from '../../components/tables/CountriesTable'
export default {
    components: {
        CountriesTable
    }
}
</script>

<style>

</style>
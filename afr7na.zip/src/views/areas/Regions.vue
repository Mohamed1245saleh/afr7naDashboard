<template>
<v-container>
    <regions-table title="المناطق" icon="my_location"/>
</v-container>
</template>

<script>
import RegionsTable from '../../components/tables/RegionsTable'
export default {
    components: {
        RegionsTable
    }
}
</script>

<style>

</style>
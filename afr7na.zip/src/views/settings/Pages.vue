<template>
<v-container>
    <pages-table title="الصفحات" icon="people"/>
</v-container>
</template>

<script>
import PagesTable from '../../components/tables/PagesTable'
export default {
  components: {
    PagesTable
  }
}
</script>

<style>
</style>

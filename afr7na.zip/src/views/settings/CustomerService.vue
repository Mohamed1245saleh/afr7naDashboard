<template>
<v-container>
    <customer-services-table title="خدمة العملاء" icon="people"/>
</v-container>
</template>

<script>
import CustomerServicesTable from '../../components/tables/CustomerServicesTable'
export default {
  components: {
    CustomerServicesTable
  }
}
</script>

<style>
</style>

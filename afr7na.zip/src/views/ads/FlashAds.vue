<template>
    <v-container>

        <flash-ads-table title="اعلانات الفلاش" icon="devices_other"/>

    </v-container>
</template>

<script>
import FlashAdsTable from '../../components/tables/FlashAdsTable'
export default {
    components: {
        FlashAdsTable
    }
}
</script>

<style>

</style>
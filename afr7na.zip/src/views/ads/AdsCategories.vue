<template>
    <v-container>

        <ads-categories-table title="الأقسام" icon="devices_other"/>

    </v-container>
</template>

<script>
import AdsCategoriesTable from '../../components/tables/AdsCategoriesTable'
export default {
    components: {
        AdsCategoriesTable
    }
}
</script>

<style>

</style>
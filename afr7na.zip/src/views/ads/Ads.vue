<template>
    <v-container>

        <ads-table title="الاعلانات" icon="devices_other"/>

    </v-container>
</template>

<script>
import AdsTable from '../../components/tables/AdsTable'
export default {
    components: {
        AdsTable
    }
}
</script>

<style>

</style>
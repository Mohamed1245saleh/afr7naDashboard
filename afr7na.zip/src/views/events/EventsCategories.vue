<template>
    <v-container>
        <events-categories-table title="الأقسام" icon="devices_other"/>
    </v-container>
</template>

<script>
import EventsCategoriesTable from '../../components/tables/EventsCategoriesTable'
export default {
    components: {
        EventsCategoriesTable
    }
}
</script>

<style>

</style>
<template>
<v-container>
    <admins-table title="المديرين" icon="people"/>
</v-container>
</template>

<script>
import AdminsTable from '../../components/tables/AdminsTable'
export default {
  components: {
    AdminsTable
  }
}
</script>

<style>
</style>

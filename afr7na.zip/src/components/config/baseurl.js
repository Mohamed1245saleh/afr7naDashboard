
const baseURL = 'http://localhost:8000/api/'
// const baseURL = 'http://afr7na.com/api/'
//
export default baseURL;

<template>
<v-container>
    <commerical-categories-table title="تصنيفات الاعلانات التجارية" icon="layers"/>
</v-container>
</template>

<script>
import CommericalCategoriesTable from '../tables/CommericalCategoriesTable'
export default {
    components: {
        CommericalCategoriesTable
    }
}
</script>

<style>

</style>

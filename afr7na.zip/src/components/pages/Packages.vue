<template>
<v-container>
    <Packages-table title="الباقة" icon="attach_money"/>
</v-container>
</template>

<script>
import PackagesTable from '../tables/PackagesTable'
export default {
    components: {
        PackagesTable
    }
}
</script>

<style>

</style>

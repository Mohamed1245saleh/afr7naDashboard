<template>
<div>
    <special-products-orders-table title="طلبات التثبيت" icon="star"/>
</div>
</template>

<script>
import SpecialProductsOrdersTable from '../tables/SpecialProductsOrdersTable'
export default {
    components: {
        SpecialProductsOrdersTable
    }
}
</script>

<style>

</style>

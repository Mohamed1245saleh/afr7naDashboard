<template>

    <ads-table title="الاعلانات" icon="content_copy"/>

</template>

<script>
import AdsTable from '../tables/AdsTable'
export default {
    components: {
        AdsTable
    }
}
</script>

<style>

</style>

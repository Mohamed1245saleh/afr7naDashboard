<template>
<v-container>
    <commerical-settings-table title="اعدادات الاعلانات التجارية" icon="settings"/>
</v-container>
</template>

<script>
import CommericalSettingsTable from '../tables/CommericalSettingsTable'
export default {
    components: {
        CommericalSettingsTable
    }
}
</script>

<style>

</style>

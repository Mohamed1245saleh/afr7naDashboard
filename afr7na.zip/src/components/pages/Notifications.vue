<template>
<v-container>
    <notifications-table title="الاشعارات" icon="language"/>
</v-container>
</template>

<script>
import NotificationsTable from '../tables/Notifications'
export default {
    components: {
        NotificationsTable
    }
}
</script>

<style>

</style>

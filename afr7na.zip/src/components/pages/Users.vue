<template>
<v-container>
    <users-table title="المستخدمين" icon="people"/>
</v-container>
</template>

<script>
import UsersTable from '../tables/UsersTable'
export default {
  components: {
    UsersTable
  }
}
</script>

<style>
</style>
